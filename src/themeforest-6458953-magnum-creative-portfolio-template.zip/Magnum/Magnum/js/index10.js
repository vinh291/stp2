$(window).load(function() {
	// Home short automatic background slider / fader
	$('#home-short-bg-fader').bxSlider({
		auto: true,
		mode: 'fade',
		speed: 2000,
		pager: false,
		controls: false,
		nextText: '',
		prevText: ''
	});
});