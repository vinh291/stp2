$(window).load(function() {
	// Home short background and content slider / fader
	$('#home-short-fader').bxSlider({
		auto: false,
		mode: 'fade',
		pager: true,
		controls: true,
		nextText: '',
		prevText: ''
	});
});